links = {
    'js': 'lib/waypoints/waypoints.min.js'
}
